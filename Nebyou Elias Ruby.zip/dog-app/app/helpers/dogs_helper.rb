module DogsHelper
end
