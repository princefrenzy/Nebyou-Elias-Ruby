class Dog < ApplicationRecord
end
